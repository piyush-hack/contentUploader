<?php 


$servername = "localhost";
$username = "id16205809_piyush";
$password = "Piyushpuniya@2001";
$dbname = "id16205809_filemanagement";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);



?>